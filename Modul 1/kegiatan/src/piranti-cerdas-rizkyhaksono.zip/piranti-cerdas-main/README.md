# Piranti Cerdas

Ini adalah repo untuk praktikum Piranti Cerdas
